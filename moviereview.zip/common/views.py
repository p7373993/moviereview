from django.contrib.auth import authenticate, login, logout
<<<<<<< Updated upstream
from django.shortcuts import render, redirect
from common.forms import UserForm

=======
from django.shortcuts import get_object_or_404, render, redirect
from common.forms import UserForm
from django.contrib.auth.decorators import user_passes_test
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth.models import User

from mypage.models import Movie, Review
>>>>>>> Stashed changes

def logout_view(request):
    logout(request)
    return redirect("index")


def signup(request):
    if request.method == "POST":
        form = UserForm(request.POST)
        print("debugw2")
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get("username")
            raw_password = form.cleaned_data.get("password1")
            user = authenticate(username=username, password=raw_password)  # 사용자 인증
            login(request, user)  # 로그인
            print("debugq1")
            return redirect("index")
    else:
        form = UserForm()
    print("debuge3")
    
    return render(request, "common/signup.html", {"form": form})
<<<<<<< Updated upstream
=======

def admin_logout(request):
    logout(request)
    return redirect('common:admin_login')

def admin_login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(request, username=username, password=password)

        if user is not None and user.is_staff:  # 관리자 권한 있는 사용자만 허용
            login(request, user)
            return redirect('common:admin_dashboard')  # 관리자 대시보드로 리디렉션
        else:
            return render(request, 'common/admin_login.html', {'error': '로그인 실패!'})

    return render(request, 'common/admin_login.html')

@user_passes_test(lambda u: u.is_staff)
def add_movie_view(request):    # 관리 페이지에서 영화 추가
    if request.method == "POST":
        title = request.POST.get("title")
        director = request.POST.get("director")
        genre = request.POST.get("genre")
        release_date = request.POST.get("release_date")
        poster = request.POST.get("poster")
        rating = request.POST.get("rating")
        description = request.POST.get("description")
        # Movie 모델에 새 인스턴스 저장
        Movie.objects.create(
            title=title,
            director=director,
            genre=genre,
            release_date=release_date,
            poster=poster,
            rating=rating,
            description=description
        )
        # 등록 후 수정 목록 페이지로 이동
        return redirect('common:edit_movie_list')
    return render(request, 'common/add_movie.html')

def delete_movie_view(request, movie_id): # 관리 페이지에서 영화 삭제
    movie = get_object_or_404(Movie, id=movie_id)
    if request.method == 'POST':
        movie.delete()
    return redirect('common:edit_movie_list')


@user_passes_test(lambda u: u.is_staff)
def user_list_view(request):
    users = User.objects.filter(is_staff=False)  # 일반 유저만 보기
    return render(request, 'common/user_list.html', {'users': users})

@user_passes_test(lambda u: u.is_staff)
def user_reviews_view(request, username):   #관리자가 유저 리뷰 보기
    user = get_object_or_404(User, username=username)
    reviews = Review.objects.filter(author=user)
    return render(request, 'common/user_reviews.html', {'user': user, 'reviews': reviews})

@user_passes_test(lambda u: u.is_staff)
def delete_review(request, review_id):  # 관리자가 유저 리뷰 삭제
    review = get_object_or_404(Review, id=review_id)
    username = review.author
    review.delete()
    return redirect('common:user_reviews', username=username)

@user_passes_test(lambda u: u.is_staff)
def admin_dashboard_view(request):
    return render(request, 'common/admin_dashboard.html')

def edit_movie_list(request):
    movies = Movie.objects.all()
    return render(request, 'common/edit_movie_list.html', {'movies': movies})

@staff_member_required  # 관리자만 접근 가능
def edit_movie(request, movie_id):
    movie = get_object_or_404(Movie, pk=movie_id)

    if request.method == 'POST':
        movie.title = request.POST['title']
        movie.director = request.POST['director']
        movie.genre = request.POST['genre']
        movie.release_date = request.POST['release_date']
        movie.poster = request.POST['poster']
        movie.rating = request.POST['rating']
        movie.description = request.POST['description']
        movie.save()
        return redirect('common:edit_movie_list')  # 수정 후 영화 목록으로

    return render(request, 'common/edit_movie.html', {'movie': movie})
>>>>>>> Stashed changes
