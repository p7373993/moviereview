from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

app_name = "common"

urlpatterns = [
<<<<<<< Updated upstream
=======
    path('admin/logout/', views.admin_logout, name='admin_logout'),
    path('admin-login/', views.admin_login_view, name='admin_login'),
    path('admin-dashboard/', views.admin_dashboard_view, name='admin_dashboard'),
    
    path('movies/edit/', views.edit_movie_list, name='edit_movie_list'),
    path('movies/<int:movie_id>/edit/', views.edit_movie, name='edit_movie'),
    path('movies/add/', views.add_movie_view, name='add_movie'),
    path('movies/<int:movie_id>/delete/', views.delete_movie_view, name='delete_movie'),
    
    path('admin/user-list/', views.user_list_view, name='user_list'),
    path('admin/users/<str:username>/reviews/', views.user_reviews_view, name='user_reviews'),
    path('admin/reviews/<int:review_id>/delete/', views.delete_review, name='delete_review'),

    
>>>>>>> Stashed changes
    path(
        "login/",
        auth_views.LoginView.as_view(template_name="common/login.html"),
        name="login",
    ),
    path(
        "logout/",
        views.logout_view,
        name="logout",
    ),
    path("signup/", views.signup, name="signup"),
]
