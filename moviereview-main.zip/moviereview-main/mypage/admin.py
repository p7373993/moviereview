from django.contrib import admin

from .models import Movie, Review

# Register your models here.
# 영화 관리자 설정
class MovieAdmin(admin.ModelAdmin):
    list_display = ('title', 'director', 'genre', 'release_date', 'rating', 'create_date')  # 목록에 표시될 필드
    search_fields = ('title', 'director')  # 검색할 수 있는 필드
    list_filter = ('genre', 'release_date')  # 필터링할 수 있는 필드
    ordering = ('-create_date',)  # 기본 정렬 기준

    # 영화 추가/수정 폼 필드 설정 (옵션)
    fields = ('title', 'director', 'genre', 'release_date', 'poster', 'rating', 'description')
    
# 리뷰 관리자 설정
class ReviewAdmin(admin.ModelAdmin):
    list_display = ('movie', 'author', 'score', 'created_at')  # 목록에 표시될 필드
    search_fields = ('movie__title', 'author')  # 영화 제목과 작성자 필드를 검색
    list_filter = ('score', 'created_at')  # 평점과 작성일 필터링

admin.site.register(Movie)
admin.site.register(Review)
