from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

app_name = "common"

urlpatterns = [
    path('admin/logout/', views.admin_logout, name='admin_logout'),
    path('admin-login/', views.admin_login_view, name='admin-login'),
    path('admin-dashboard/', views.admin_dashboard_view, name='admin_dashboard'),
    path(
        "login/",
        auth_views.LoginView.as_view(template_name="common/login.html"),
        name="login",
    ),
    path(
        "logout/",
        views.logout_view,
        name="logout",
    ),
    path("signup/", views.signup, name="signup"),
]
