from django.contrib.auth import authenticate, login, logout
from django.shortcuts import render, redirect
from common.forms import UserForm
from django.contrib.auth.decorators import user_passes_test

def logout_view(request):
    logout(request)
    return redirect("index")

def signup(request):
    if request.method == "POST":
        form = UserForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get("username")
            raw_password = form.cleaned_data.get("password1")
            user = authenticate(username=username, password=raw_password)  # 사용자 인증
            login(request, user)  # 로그인
            return redirect("index")
    else:
        form = UserForm()
    return render(request, "common/signup.html", {"form": form})

def admin_logout(request):
    logout(request)
    return redirect('admin_login')

def admin_login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(request, username=username, password=password)

        if user is not None and user.is_staff:  # 관리자 권한 있는 사용자만 허용
            login(request, user)
            return redirect('common:admin_dashboard')  # 관리자 대시보드로 리디렉션
        else:
            return render(request, 'common/admin_login.html', {'error': '로그인 실패!'})

    return render(request, 'common/admin_login.html')

@user_passes_test(lambda u: u.is_staff)
def admin_dashboard_view(request):
    return render(request, 'common/admin_dashboard.html')